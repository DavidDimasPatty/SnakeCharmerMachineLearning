
# SnakeCharmerMachineLearning




## Requirements

- Java SDK version > 18
- Java SE version > 18


## How To Run Project

- open cmd in directory project
- javac SnakeCharmerTester.java
- java SnakeCharmerTester.java
- input your loop(ex: 100)


## Change Input
You can change the size of the board and the number of different section values in input.txt file


